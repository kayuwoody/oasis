# POS Full Project

This folder contains the full POS frontend for deployment.